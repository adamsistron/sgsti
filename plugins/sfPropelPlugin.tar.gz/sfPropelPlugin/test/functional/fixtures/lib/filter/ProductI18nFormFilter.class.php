<?php

/**
 * ProductI18n filter form.
 *
 * @package    ##PROJECT_NAME##
 * @subpackage filter
 * @author     Your name here
 * @version    SVN: $Id: sfPropelFormFilterTemplate.php 11675 2008-09-19 15:21:38Z fabien $
 */
class ProductI18nFormFilter extends BaseProductI18nFormFilter
{
  public function configure()
  {
  }
}
