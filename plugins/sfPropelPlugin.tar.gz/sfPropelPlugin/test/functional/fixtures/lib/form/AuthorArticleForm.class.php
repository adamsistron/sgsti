<?php

/**
 * AuthorArticle form.
 *
 * @package    form
 * @subpackage author_article
 * @version    SVN: $Id: AuthorArticleForm.class.php 6884 2008-01-02 10:32:24Z dwhittle $
 */
class AuthorArticleForm extends BaseAuthorArticleForm
{
  public function configure()
  {
  }
}
