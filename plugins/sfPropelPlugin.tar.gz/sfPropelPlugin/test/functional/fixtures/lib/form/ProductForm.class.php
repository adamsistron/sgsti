<?php

/**
 * Product form.
 *
 * @package    form
 * @subpackage product
 * @version    SVN: $Id: sfPropelFormTemplate.php 6180 2007-11-27 18:50:50Z dwhittle $
 */
class ProductForm extends BaseProductForm
{
  public function configure()
  {
  }
}
