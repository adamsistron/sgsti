<?php

/**
 * MovieI18n form.
 *
 * @package    form
 * @subpackage movie_i18n
 * @version    SVN: $Id: MovieI18nForm.class.php 8424 2008-04-11 18:23:01Z dwhittle $
 */
class MovieI18nForm extends BaseMovieI18nForm
{
  public function configure()
  {
  }
}
