<?php

/**
 * ProductI18n form.
 *
 * @package    form
 * @subpackage product_i18n
 * @version    SVN: $Id: sfPropelFormTemplate.php 6180 2007-11-27 18:50:50Z dwhittle $
 */
class ProductI18nForm extends BaseProductI18nForm
{
  public function configure()
  {
  }
}
