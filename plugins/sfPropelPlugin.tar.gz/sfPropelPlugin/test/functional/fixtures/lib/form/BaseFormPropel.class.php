<?php

/**
 * Project form base class.
 *
 * @package    form
 * @version    SVN: $Id: BaseFormPropel.class.php 6884 2008-01-02 10:32:24Z dwhittle $
 */
abstract class BaseFormPropel extends sfFormPropel
{
  public function setup()
  {
  }
}
