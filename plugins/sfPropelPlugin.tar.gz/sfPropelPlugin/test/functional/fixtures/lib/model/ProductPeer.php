<?php

/**
 * Subclass for performing query and update operations on the 'product' table.
 *
 * 
 *
 * @package    lib.model
 * @subpackage model
 */
class ProductPeer extends BaseProductPeer
{
}
