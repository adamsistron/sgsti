<?php

/**
 * Subclass for performing query and update operations on the 'author_article' table.
 *
 * 
 *
 * @package lib.model
 */ 
class AuthorArticlePeer extends BaseAuthorArticlePeer
{
}
