<?php

/**
 * Subclass for performing query and update operations on the 'movie_i18n' table.
 *
 * 
 *
 * @package lib.model
 */ 
class MovieI18nPeer extends BaseMovieI18nPeer
{
}
