<?php

/**
 * Subclass for representing a row from the 'movie' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Movie extends BaseMovie
{
}
